# ScamGuardAI 🛡️

### AI-Powered Fraud Detection & Reporting Network

**ScamGuardAI** is an AI-driven decentralized system that detects, reports, and prevents online scams across multiple communication channels.

---

## 🚀 Features
- **AI-powered scam detection** using NLP, Vision, and Voice AI.
- **Blockchain-backed verification** of scam reports.
- **Decentralized registry** of reported scams for transparency.
- **Web extension & mobile-ready frontend.**

---

## 🧩 Tech Stack
- **Smart Contracts:** Solidity, deployed on Ethereum/compatible chains.
- **Frontend:** React.js + Web3.js + AI APIs.
- **Backend:** Node.js for threat aggregation.
- **AI Models:** OpenAI embeddings, Vision Transformers, Speech2Text for voice scams.

---

## 🧠 How It Works
1. AI models analyze incoming messages (text, image, or voice).
2. Detected scams are hashed and stored via the `ScamReportRegistry` smart contract.
3. Users can query or verify scam reports on-chain.
4. Crowdsourced reporting strengthens the model accuracy over time.

---

## 🧰 Setup

```bash
# Install dependencies
npm install

# Compile smart contracts
npx hardhat compile

# Run frontend
cd frontend
npm start
```

---

## 🤖 AI Integration
- **Text Analysis:** LLMs detect phishing intent and linguistic patterns.
- **Vision AI:** Detects deepfakes and fake documents.
- **Voice AI:** Identifies impersonation and synthetic voices.

---

## 🌍 Vision
To become the universal digital shield protecting people and organizations from online fraud, phishing, and AI-generated deception.

---

## 📜 License
MIT © 2025 ScamGuardAI Team
